package com.example.island

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val prefs = getSharedPreferences("island", MODE_PRIVATE)
        val density = resources.displayMetrics.density
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
        }

        fun button(text: String, onClick: () -> Unit) = Button(this).apply {
            this.text = text
            setOnClickListener { onClick() }
            box.addView(this)
        }

        fun header(text: String) {
            box.addView(TextView(this).apply {
                this.text = "\n$text"
                textSize = 18f
                setTypeface(typeface, Typeface.BOLD)
            })
        }

        fun withIsland(action: (IslandService) -> Unit) {
            val s = IslandService.instance
            if (s == null) {
                Toast.makeText(this, "Сначала запустите остров", Toast.LENGTH_SHORT).show()
            } else {
                action(s)
            }
        }

        // Отдельный переключатель для каждой функции
        fun toggle(label: String, key: String, def: Boolean) {
            val sw = Switch(this)
            sw.text = label
            sw.setPadding(0, 16, 0, 16)
            sw.isChecked = prefs.getBoolean(key, def)
            sw.setOnCheckedChangeListener { _, v ->
                prefs.edit().putBoolean(key, v).apply()
                IslandService.instance?.applySettings()
            }
            box.addView(sw)
        }

        fun slider(label: String, key: String, max: Int, def: Int, onChange: (() -> Unit)? = null) {
            val tv = TextView(this)
            tv.text = "$label: ${prefs.getInt(key, def)}"
            val sb = SeekBar(this)
            sb.max = max
            sb.progress = prefs.getInt(key, def)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    prefs.edit().putInt(key, v).apply()
                    tv.text = "$label: $v"
                    onChange?.invoke()
                    IslandService.instance?.applySettings()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            box.addView(tv)
            box.addView(sb)
        }

        // Выбор цвета: образец + три ползунка RGB
        fun colorPicker(rKey: String, gKey: String, bKey: String, dr: Int, dg: Int, db: Int) {
            val preview = View(this)
            fun update() {
                preview.setBackgroundColor(
                    Color.rgb(prefs.getInt(rKey, dr), prefs.getInt(gKey, dg), prefs.getInt(bKey, db))
                )
            }
            update()
            box.addView(
                preview,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (32 * density).toInt())
            )
            slider("Красный", rKey, 255, dr) { update() }
            slider("Зелёный", gKey, 255, dg) { update() }
            slider("Синий", bKey, 255, db) { update() }
        }

        // ---------- запуск ----------
        button("1. Разрешить поверх других окон") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("2. Доступ к уведомлениям (для уведомлений, музыки, звонков)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        button("3. Запустить остров") {
            if (Settings.canDrawOverlays(this)) {
                startForegroundService(Intent(this, IslandService::class.java))
            } else {
                Toast.makeText(this, "Сначала шаг 1", Toast.LENGTH_SHORT).show()
            }
        }
        button("Остановить") { stopService(Intent(this, IslandService::class.java)) }

        header("Уведомления")
        button("Тестовое уведомление") {
            withIsland { it.onNotification(Info(null, "Тест", "Привет из острова!", null)) }
        }

        // ---------- Музыка ----------
        header("Музыка")
        toggle("Название трека", "m_title", true)
        toggle("Кнопки управления (⏮ ⏯ ⏭)", "m_btns", true)

        // ---------- Звонки и таймер ----------
        header("Звонки")
        toggle("Индикатор звонка", "call_ind", true)
        button("Тест: входящий звонок") {
            withIsland { it.onCall(Info(null, "Тестовый контакт", "Входящий", null)) }
        }
        button("Тест: завершить звонок") { withIsland { it.onCall(null) } }

        header("Таймер")
        button("Таймер 1 мин") { withIsland { it.startTimer(60) } }
        button("Таймер 5 мин") { withIsland { it.startTimer(300) } }
        button("Отменить таймер") { withIsland { it.cancelTimer() } }

        header("Секундомер")
        button("Старт / пауза") { withIsland { it.toggleStopwatch() } }
        button("Сброс") { withIsland { it.resetStopwatch() } }

        // ---------- Цвета и стили ----------
        header("Свой цвет")
        toggle("Использовать свой цвет", "c_on", false)
        colorPicker("c_r", "c_g", "c_b", 0, 0, 0)

        header("Обводка")
        toggle("Показывать обводку", "s_on", false)
        slider("Толщина (dp)", "s_w", 8, 2)
        colorPicker("s_r", "s_g", "s_b", 255, 255, 255)

        header("Прозрачность")
        toggle("Включить прозрачность", "a_on", false)
        slider("Непрозрачность (%)", "a", 100, 100)

        // ---------- размер и положение ----------
        header("Размер и положение")
        slider("Ширина (dp)", "w", 300, 120)
        slider("Высота (dp)", "h", 120, 34)
        slider("Позиция X (100 = центр)", "x", 200, 100)
        slider("Позиция Y (dp)", "y", 100, 6)
        slider("Скругление (dp)", "r", 100, 50)

        setContentView(ScrollView(this).apply { addView(box) })
    }
}
