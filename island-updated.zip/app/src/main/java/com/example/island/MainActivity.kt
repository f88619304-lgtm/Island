package com.example.island

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val prefs = getSharedPreferences("island", MODE_PRIVATE)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
        }

        fun button(text: String, onClick: () -> Unit) = Button(this).apply {
            this.text = text
            setOnClickListener { onClick() }
            box.addView(this)
        }

        fun withIsland(action: (IslandService) -> Unit) {
            val s = IslandService.instance
            if (s == null) {
                Toast.makeText(this, "Сначала запустите остров", Toast.LENGTH_SHORT).show()
            } else {
                action(s)
            }
        }

        fun slider(label: String, key: String, max: Int, def: Int) {
            val tv = TextView(this)
            tv.text = "$label: ${prefs.getInt(key, def)}"
            val sb = SeekBar(this)
            sb.max = max
            sb.progress = prefs.getInt(key, def)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    prefs.edit().putInt(key, v).apply()
                    tv.text = "$label: $v"
                    IslandService.instance?.applySettings()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            box.addView(tv)
            box.addView(sb)
        }

        button("1. Разрешить поверх других окон") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("2. Доступ к уведомлениям (для уведомлений, музыки, звонков)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        button("3. Запустить остров") {
            if (Settings.canDrawOverlays(this)) {
                startForegroundService(Intent(this, IslandService::class.java))
            } else {
                Toast.makeText(this, "Сначала шаг 1", Toast.LENGTH_SHORT).show()
            }
        }
        button("Остановить") { stopService(Intent(this, IslandService::class.java)) }

        box.addView(TextView(this).apply { text = "\nПроверка"; textSize = 16f })
        button("Тестовое уведомление") {
            withIsland { it.onNotification(Info(null, "Тест", "Привет из острова!", null)) }
        }
        button("Таймер 1 мин") { withIsland { it.startTimer(60) } }
        button("Таймер 5 мин") { withIsland { it.startTimer(300) } }
        button("Отменить таймер") { withIsland { it.cancelTimer() } }

        box.addView(TextView(this).apply { text = "\nВнешний вид"; textSize = 16f })
        slider("Ширина (dp)", "w", 300, 120)
        slider("Высота (dp)", "h", 120, 34)
        slider("Позиция X (100 = центр)", "x", 200, 100)
        slider("Позиция Y (dp)", "y", 100, 6)
        slider("Скругление (dp)", "r", 100, 50)

        box.addView(TextView(this).apply { text = "\nЦвет и прозрачность"; textSize = 16f })
        slider("Красный (RGB)", "red", 255, 0)
        slider("Зелёный (RGB)", "green", 255, 0)
        slider("Синий (RGB)", "blue", 255, 0)
        slider("Прозрачность (%)", "opacity", 100, 100)
        slider("Цвет обводки, красный", "ored", 255, 80)
        slider("Цвет обводки, зелёный", "ogreen", 255, 180)
        slider("Цвет обводки, синий", "oblue", 255, 255)
        button("Включить / выключить обводку") {
            val enabled = !prefs.getBoolean("outline", true)
            prefs.edit().putBoolean("outline", enabled).apply()
            IslandService.instance?.applySettings()
            Toast.makeText(this, if (enabled) "Обводка включена" else "Обводка выключена", Toast.LENGTH_SHORT).show()
        }
        box.addView(TextView(this).apply { text = "\nСекундомер"; textSize = 16f })
        button("Запустить секундомер") { withIsland { it.startStopwatch() } }
        button("Пауза / продолжить секундомер") { withIsland { it.toggleStopwatch() } }
        button("Сбросить секундомер") { withIsland { it.resetStopwatch() } }

        setContentView(ScrollView(this).apply { addView(box) })
    }
}
