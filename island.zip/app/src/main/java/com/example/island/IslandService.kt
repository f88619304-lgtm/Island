package com.example.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var island: View
    private lateinit var lp: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("island", "Island", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "island")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Dynamic Island работает")
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        island = View(this)
        lp = WindowManager.LayoutParams(
            0, 0,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        applySettings()
        wm.addView(island, lp)
    }

    fun applySettings() {
        val p = getSharedPreferences("island", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        lp.width = ((p.getInt("w", 120)) * d).toInt()
        lp.height = ((p.getInt("h", 34)) * d).toInt()
        lp.x = ((p.getInt("x", 100) - 100) * d).toInt() // 100 = по центру
        lp.y = ((p.getInt("y", 6)) * d).toInt()
        island.background = GradientDrawable().apply {
            setColor(Color.BLACK)
            cornerRadius = p.getInt("r", 50) * d
        }
        if (island.isAttachedToWindow) wm.updateViewLayout(island, lp)
    }

    override fun onDestroy() {
        if (::island.isInitialized && island.isAttachedToWindow) wm.removeView(island)
        instance = null
        super.onDestroy()
    }

    companion object {
        var instance: IslandService? = null
    }
}
