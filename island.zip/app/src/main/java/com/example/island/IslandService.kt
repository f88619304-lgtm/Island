package com.example.island

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class Info(val icon: Drawable?, val title: String, val text: String, val intent: PendingIntent?)

enum class Kind { NONE, NOTIF, CALL, TIMER, MEDIA }

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: FrameLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var bg: GradientDrawable
    private lateinit var smallText: TextView
    private lateinit var bigRow: LinearLayout
    private lateinit var iconView: ImageView
    private lateinit var titleView: TextView
    private lateinit var subView: TextView
    private lateinit var btnPrev: TextView
    private lateinit var btnPlay: TextView
    private lateinit var btnNext: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val density: Float get() = resources.displayMetrics.density
    private fun dp(v: Int): Int = (v * density).toInt()
    private fun prefs() = getSharedPreferences("island", MODE_PRIVATE)

    private var expanded = false
    private var shown = Kind.NONE
    private var lastNotif: Info? = null
    private var call: Info? = null
    private var timerEnd = 0L
    private var controller: MediaController? = null
    private var lastTitle: String? = null
    private var anim: ValueAnimator? = null
    private var sessionsRegistered = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("island", "Island", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "island")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Dynamic Island работает")
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildViews()

        lp = WindowManager.LayoutParams(
            dp(120), dp(34),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        layout(false)
        wm.addView(root, lp)
        refreshMedia()
    }

    private fun buildViews() {
        bg = GradientDrawable().apply { setColor(Color.BLACK) }
        root = FrameLayout(this).apply {
            background = bg
            setOnClickListener { onTap() }
        }
        smallText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(10), 0, dp(10), 0)
            visibility = View.GONE
        }
        root.addView(
            smallText,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        bigRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
            visibility = View.GONE
        }
        iconView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(10).toFloat())
                }
            }
            clipToOutline = true
        }
        bigRow.addView(iconView, LinearLayout.LayoutParams(dp(44), dp(44)))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleView = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        subView = TextView(this).apply {
            setTextColor(Color.parseColor("#BBBBBB"))
            textSize = 12f
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        col.addView(titleView)
        col.addView(subView)
        val colLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        colLp.leftMargin = dp(12)
        bigRow.addView(col, colLp)

        fun ctl(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { onClick() }
        }
        btnPrev = ctl("⏮") { if (shown == Kind.MEDIA) controller?.transportControls?.skipToPrevious() }
        btnPlay = ctl("▶") {
            if (shown == Kind.MEDIA) {
                val c = controller
                if (c?.playbackState?.state == PlaybackState.STATE_PLAYING) {
                    c.transportControls.pause()
                } else {
                    c?.transportControls?.play()
                }
            } else if (shown == Kind.TIMER) {
                cancelTimer()
            }
        }
        btnNext = ctl("⏭") { if (shown == Kind.MEDIA) controller?.transportControls?.skipToNext() }
        val ctrls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ctrls.addView(btnPrev)
        ctrls.addView(btnPlay)
        ctrls.addView(btnNext)
        bigRow.addView(ctrls)

        root.addView(
            bigRow,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
    }

    // ---------- размеры и анимация ----------

    private fun targetSize(showBig: Boolean): Pair<Int, Int> {
        val p = prefs()
        val cw = dp(p.getInt("w", 120))
        val ch = dp(p.getInt("h", 34))
        if (showBig) {
            val screenW = resources.displayMetrics.widthPixels
            val w = minOf(screenW - dp(24), dp(360))
            val h = dp(if (shown == Kind.MEDIA) 96 else 84)
            return Pair(w, h)
        }
        if (call != null || timerEnd > 0) return Pair(cw + dp(70), ch)
        return Pair(cw, ch)
    }

    private fun place(w: Int, h: Int) {
        val p = prefs()
        lp.width = w
        lp.height = h
        lp.x = ((p.getInt("x", 100) - 100) * density).toInt()
        lp.y = (p.getInt("y", 6) * density).toInt()
        bg.cornerRadius = minOf(p.getInt("r", 50) * density, h / 2f)
        if (root.isAttachedToWindow) wm.updateViewLayout(root, lp)
    }

    private fun smallLabel(): String? = when {
        call != null -> "📞 " + call!!.title
        timerEnd > 0 -> "⏱ " + fmt(timerEnd - SystemClock.elapsedRealtime())
        else -> null
    }

    private fun fmt(ms: Long): String {
        val s = maxOf(0L, (ms + 999) / 1000)
        return String.format("%d:%02d", s / 60, s % 60)
    }

    private fun layout(animate: Boolean) {
        val showBig = expanded && shown != Kind.NONE
        val size = targetSize(showBig)
        val tw = size.first
        val th = size.second
        val label = if (showBig) null else smallLabel()
        if (showBig) fill()
        smallText.text = label ?: ""

        val old = anim
        anim = null
        old?.cancel()

        if (!animate) {
            bigRow.visibility = if (showBig) View.VISIBLE else View.GONE
            bigRow.alpha = 1f
            smallText.visibility = if (label != null) View.VISIBLE else View.GONE
            smallText.alpha = 1f
            place(tw, th)
            return
        }

        val startW = lp.width
        val startH = lp.height
        if (showBig) {
            bigRow.visibility = View.VISIBLE
            smallText.visibility = View.GONE
        } else {
            smallText.visibility = if (label != null) View.VISIBLE else View.GONE
        }
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 340
        a.interpolator = OvershootInterpolator(if (showBig) 1.1f else 0.6f)
        a.addUpdateListener { v ->
            val f = v.animatedValue as Float
            place((startW + (tw - startW) * f).toInt(), (startH + (th - startH) * f).toInt())
            val fc = f.coerceIn(0f, 1f)
            if (showBig) {
                bigRow.alpha = fc
            } else {
                bigRow.alpha = 1f - fc
                smallText.alpha = fc
            }
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                if (anim === a && !showBig) {
                    bigRow.visibility = View.GONE
                    bigRow.alpha = 1f
                }
            }
        })
        anim = a
        a.start()
    }

    private fun fill() {
        var icon: Drawable? = null
        var title = ""
        var sub = ""
        when (shown) {
            Kind.CALL -> call?.let {
                icon = it.icon
                title = it.title
                sub = "Звонок  " + it.text
            }
            Kind.NOTIF -> lastNotif?.let {
                icon = it.icon
                title = it.title
                sub = it.text
            }
            Kind.TIMER -> {
                title = fmt(timerEnd - SystemClock.elapsedRealtime())
                sub = "Таймер"
            }
            Kind.MEDIA -> {
                val m = controller?.metadata
                title = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Музыка"
                sub = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
                val art = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                if (art != null) icon = BitmapDrawable(resources, art)
                val playing = controller?.playbackState?.state == PlaybackState.STATE_PLAYING
                btnPlay.text = if (playing) "⏸" else "▶"
            }
            else -> {}
        }
        iconView.setImageDrawable(icon)
        iconView.visibility = if (icon != null) View.VISIBLE else View.GONE
        titleView.text = title
        subView.text = sub
        subView.visibility = if (sub.isEmpty()) View.GONE else View.VISIBLE
        when (shown) {
            Kind.MEDIA -> {
                btnPrev.visibility = View.VISIBLE
                btnPlay.visibility = View.VISIBLE
                btnNext.visibility = View.VISIBLE
            }
            Kind.TIMER -> {
                btnPrev.visibility = View.GONE
                btnNext.visibility = View.GONE
                btnPlay.visibility = View.VISIBLE
                btnPlay.text = "✕"
            }
            else -> {
                btnPrev.visibility = View.GONE
                btnPlay.visibility = View.GONE
                btnNext.visibility = View.GONE
            }
        }
    }

    // ---------- поведение ----------

    private val collapseRunnable = Runnable {
        expanded = false
        layout(true)
    }

    private fun autoShow(kind: Kind, ms: Long) {
        shown = kind
        expanded = true
        layout(true)
        handler.removeCallbacks(collapseRunnable)
        handler.postDelayed(collapseRunnable, ms)
    }

    private fun onTap() {
        handler.removeCallbacks(collapseRunnable)
        if (expanded) {
            val pi = when (shown) {
                Kind.NOTIF -> lastNotif?.intent
                Kind.CALL -> call?.intent
                else -> null
            }
            if (pi != null) {
                try {
                    pi.send()
                } catch (e: Exception) {
                }
            }
            expanded = false
            layout(true)
        } else {
            shown = when {
                call != null -> Kind.CALL
                timerEnd > 0 -> Kind.TIMER
                controller != null -> Kind.MEDIA
                lastNotif != null -> Kind.NOTIF
                else -> Kind.NONE
            }
            if (shown != Kind.NONE) {
                expanded = true
                layout(true)
            }
        }
    }

    fun applySettings() {
        layout(false)
    }

    fun onNotification(info: Info) {
        lastNotif = info
        autoShow(Kind.NOTIF, 5000)
    }

    fun onCall(info: Info?) {
        val wasNull = call == null
        call = info
        if (info != null && wasNull) {
            autoShow(Kind.CALL, 6000)
        } else {
            if (info == null && shown == Kind.CALL) expanded = false
            layout(true)
        }
    }

    // ---------- таймер ----------

    private val ticker = object : Runnable {
        override fun run() {
            if (timerEnd <= 0) return
            val left = timerEnd - SystemClock.elapsedRealtime()
            if (left <= 0) {
                timerEnd = 0
                finishTimer()
            } else {
                if (!expanded) {
                    smallLabel()?.let { smallText.text = it }
                } else if (shown == Kind.TIMER) {
                    titleView.text = fmt(left)
                }
                handler.postDelayed(this, 500)
            }
        }
    }

    fun startTimer(seconds: Int) {
        timerEnd = SystemClock.elapsedRealtime() + seconds * 1000L
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        layout(true)
    }

    fun cancelTimer() {
        timerEnd = 0
        handler.removeCallbacks(ticker)
        if (shown == Kind.TIMER) expanded = false
        layout(true)
    }

    private fun finishTimer() {
        try {
            getSystemService(Vibrator::class.java)
                ?.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
        }
        onNotification(Info(null, "Таймер завершён", "Время вышло", null))
    }

    // ---------- музыка ----------

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }

    private val mediaCb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            if (metadata == null) return
            val t = metadata.getString(MediaMetadata.METADATA_KEY_TITLE)
            if (t == lastTitle) {
                if (expanded && shown == Kind.MEDIA) fill()
                return
            }
            lastTitle = t
            if (call != null) return
            if (controller?.playbackState?.state == PlaybackState.STATE_PLAYING) {
                autoShow(Kind.MEDIA, 4000)
            } else if (expanded && shown == Kind.MEDIA) {
                fill()
            }
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            if (expanded && shown == Kind.MEDIA) fill()
        }
    }

    fun refreshMedia() {
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(this, NotifListener::class.java)
            if (!sessionsRegistered) {
                msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
                sessionsRegistered = true
            }
            pick(msm.getActiveSessions(cn))
        } catch (e: SecurityException) {
        }
    }

    private fun pick(list: List<MediaController>?) {
        val best = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        if (best?.sessionToken == controller?.sessionToken) return
        controller?.unregisterCallback(mediaCb)
        controller = best
        best?.registerCallback(mediaCb)
        if (expanded && shown == Kind.MEDIA) fill()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        anim?.cancel()
        controller?.unregisterCallback(mediaCb)
        if (sessionsRegistered) {
            try {
                getSystemService(MediaSessionManager::class.java)
                    .removeOnActiveSessionsChangedListener(sessionsListener)
            } catch (e: Exception) {
            }
        }
        if (::root.isInitialized && root.isAttachedToWindow) wm.removeView(root)
        instance = null
        super.onDestroy()
    }

    companion object {
        var instance: IslandService? = null
    }
}
